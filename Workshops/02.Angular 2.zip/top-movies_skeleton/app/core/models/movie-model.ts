export class MovieDetails {
    Title: string;
    Year: string;
    Poster: string;
    imdbRating: string;
}
